package com.example.ytdl

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/** منطق التحميل المشترك بين الشاشة الرئيسية وخدمة الخلفية */
object Downloader {

    /** الخيارات المعروضة للمستخدم: الاسم -> (صوت فقط؟، أقصى ارتفاع؛ 0 = أفضل) */
    val choices = linkedMapOf(
        "🎬 فيديو — أفضل جودة" to (false to 0),
        "🎬 فيديو 1080p" to (false to 1080),
        "🎬 فيديو 720p" to (false to 720),
        "🎬 فيديو 480p" to (false to 480),
        "🎬 فيديو 360p" to (false to 360),
        "🎵 صوت فقط MP3" to (true to 0),
    )

    @Volatile private var initialized = false

    @Synchronized
    fun init(context: Context) {
        if (initialized) return
        YoutubeDL.getInstance().init(context.applicationContext)
        FFmpeg.getInstance().init(context.applicationContext)
        initialized = true
    }

    fun buildRequest(url: String, outDir: File, audioOnly: Boolean, height: Int) =
        YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("-o", "${outDir.absolutePath}/%(title).80s.%(ext)s")
            if (audioOnly) {
                addOption("-f", "bestaudio/best")
                addOption("-x")
                addOption("--audio-format", "mp3")
                addOption("--audio-quality", "0")
            } else {
                val f = if (height == 0) "bv*+ba/b"
                        else "bv*[height<=$height]+ba/b[height<=$height]/b"
                addOption("-f", f)
                addOption("--merge-output-format", "mp4")
            }
        }

    /** نسخ الملف إلى Download/YTDownloader. يعيد (المسار الظاهر، Uri للفتح إن وُجد) */
    fun saveToDownloads(context: Context, file: File, audio: Boolean): Pair<String, Uri?> {
        val folder = "YTDownloader"
        val mime = if (audio) "audio/mpeg" else "video/mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH,
                    "${Environment.DIRECTORY_DOWNLOADS}/$folder")
            }
            val uri = context.contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
            ) ?: throw Exception("تعذّر إنشاء الملف")
            context.contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            "Download/$folder/${file.name}" to uri
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), folder).apply { mkdirs() }
            val dest = File(dir, file.name)
            file.copyTo(dest, overwrite = true)
            dest.absolutePath to null
        }
    }

    fun extractUrl(text: String?): String? =
        text?.let { Regex("https?://\\S+").find(it)?.value }
}
