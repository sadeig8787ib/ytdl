package com.example.ytdl

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton

/**
 * شاشة شفافة تعرض قائمة سفلية لاختيار نوع التحميل.
 * تُفتح من: زر "مشاركة" في يوتيوب، أو الضغط على الأيقونة العائمة (تقرأ الرابط المنسوخ).
 */
class ShareActivity : AppCompatActivity() {

    companion object { const val EXTRA_FROM_BUBBLE = "from_bubble" }

    private var url: String? = null
    private var sheet: BottomSheetDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(intent: Intent) {
        url = null
        if (intent.action == Intent.ACTION_SEND) {
            url = Downloader.extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))
            showSheet()
        }
        // من الأيقونة العائمة: ننتظر onWindowFocusChanged لأن أندرويد 10+ لا يسمح
        // بقراءة الحافظة إلا والتطبيق في المقدمة ومُركَّز عليه
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && url == null && sheet == null &&
            intent.getBooleanExtra(EXTRA_FROM_BUBBLE, false)) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(this)?.toString()
            url = Downloader.extractUrl(text)
            if (url == null) {
                Toast.makeText(this,
                    "انسخ رابط الفيديو أولاً: مشاركة ← نسخ الرابط، ثم اضغط الأيقونة",
                    Toast.LENGTH_LONG).show()
                finish()
            } else showSheet()
        }
    }

    private fun showSheet() {
        val link = url
        if (link == null) {
            Toast.makeText(this, "لم أجد رابطاً", Toast.LENGTH_SHORT).show()
            finish(); return
        }
        sheet?.apply { setOnDismissListener(null); dismiss() }

        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        box.addView(TextView(this).apply {
            text = "اختر نوع التحميل"; textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = link; textSize = 12f; maxLines = 1; alpha = 0.6f
            gravity = Gravity.START; setPadding(0, 8, 0, pad / 2)
        })

        val dialog = BottomSheetDialog(this)
        for ((label, opt) in Downloader.choices) {
            box.addView(MaterialButton(this, null,
                com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = label
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnClickListener {
                    DownloadService.start(this@ShareActivity, link, opt.first, opt.second)
                    Toast.makeText(this@ShareActivity,
                        "بدأ التحميل — تابعه من الإشعارات", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            })
        }
        dialog.setContentView(box)
        dialog.setOnDismissListener { sheet = null; finish() }
        sheet = dialog
        dialog.show()
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION") overridePendingTransition(0, 0)
    }
}
