package com.example.ytdl

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var qualitySpinner: Spinner
    private lateinit var videoBtn: Button
    private lateinit var audioBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var bubbleBtn: Button
    private lateinit var progress: LinearProgressIndicator
    private lateinit var status: TextView

    private val processId = "main-download"
    private var ready = false
    private val heights = listOf(0, 1080, 720, 480, 360)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        qualitySpinner = findViewById(R.id.qualitySpinner)
        videoBtn = findViewById(R.id.videoBtn)
        audioBtn = findViewById(R.id.audioBtn)
        cancelBtn = findViewById(R.id.cancelBtn)
        updateBtn = findViewById(R.id.updateBtn)
        bubbleBtn = findViewById(R.id.bubbleBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        qualitySpinner.adapter = ArrayAdapter(this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("أفضل جودة", "1080p", "720p", "480p", "360p"))

        when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ->
                requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
            Build.VERSION.SDK_INT >= 33 ->
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        setBusy(true)
        initEngine()

        videoBtn.setOnClickListener { startDownload(audioOnly = false) }
        audioBtn.setOnClickListener { startDownload(audioOnly = true) }
        cancelBtn.setOnClickListener { YoutubeDL.getInstance().destroyProcessById(processId) }
        updateBtn.setOnClickListener { updateEngine() }
        bubbleBtn.setOnClickListener { explainBubble() }
    }

    private fun explainBubble() {
        AlertDialog.Builder(this)
            .setTitle("الأيقونة العائمة")
            .setMessage(
                "ستظهر أيقونة حمراء صغيرة عند فتح يوتيوب فقط.\n\n" +
                "للتفعيل: في الصفحة التالية اختر «التطبيقات المثبّتة» ← «أيقونة التحميل العائمة» ← تشغيل.\n\n" +
                "إن كان الخيار رمادياً (أندرويد 13+): افتح إعدادات التطبيق ← ⋮ أعلى الشاشة ← «السماح بالإعدادات المقيّدة» ثم عد وفعّله.\n\n" +
                "الاستخدام: في يوتيوب اضغط مشاركة ← نسخ الرابط، ثم اضغط الأيقونة.")
            .setPositiveButton("فتح الإعدادات") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton("إعدادات التطبيق") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.parse("package:$packageName")))
            }
            .show()
    }

    private fun initEngine() = lifecycleScope.launch {
        try {
            withContext(Dispatchers.IO) { Downloader.init(this@MainActivity) }
            ready = true
            status.text = "جاهز ✓\nنصيحة: يمكنك أيضاً مشاركة الفيديو من يوتيوب مباشرة إلى «تحميل»."
        } catch (e: Exception) {
            status.text = "فشل تجهيز المحرّك: ${e.message}"
        }
        setBusy(false)
    }

    private fun updateEngine() = lifecycleScope.launch {
        setBusy(true)
        status.text = "جاري تحديث yt-dlp..."
        try {
            val result = withContext(Dispatchers.IO) {
                YoutubeDL.getInstance().updateYoutubeDL(
                    applicationContext, YoutubeDL.UpdateChannel.STABLE)
            }
            status.text = "نتيجة التحديث: $result"
        } catch (e: Exception) {
            status.text = "فشل التحديث: ${e.message}"
        }
        setBusy(false)
    }

    private fun startDownload(audioOnly: Boolean) {
        val url = urlInput.text.toString().trim()
        if (!ready) return toast("المحرّك غير جاهز بعد")
        if (!url.startsWith("http")) return toast("أدخل رابطاً صحيحاً")

        val tempDir = File(cacheDir, "main-dl").apply { deleteRecursively(); mkdirs() }
        val request = Downloader.buildRequest(
            url, tempDir, audioOnly, heights[qualitySpinner.selectedItemPosition])

        setBusy(true, downloading = true)
        progress.progress = 0
        status.text = "جاري جلب المعلومات..."

        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().execute(request, processId) { p, eta, _ ->
                        runOnUiThread {
                            if (p >= 0) {
                                progress.setProgressCompat(p.toInt(), true)
                                status.text = "جاري التحميل: ${p.toInt()}%  —  متبقٍّ $eta ث"
                            }
                        }
                    }
                }
                val file = tempDir.listFiles()?.maxByOrNull { it.length() }
                    ?: throw Exception("لم يتم العثور على الملف")
                status.text = "جاري الحفظ..."
                val (path, _) = withContext(Dispatchers.IO) {
                    Downloader.saveToDownloads(this@MainActivity, file, audioOnly)
                }
                status.text = "تم الحفظ ✓\n$path"
                progress.setProgressCompat(100, true)
            } catch (e: YoutubeDL.CanceledException) {
                status.text = "تم الإلغاء"
            } catch (e: Exception) {
                status.text = "خطأ: ${e.message?.takeLast(400)}\n\nجرّب زر تحديث المحرّك."
            } finally {
                tempDir.deleteRecursively()
                setBusy(false)
            }
        }
    }

    private fun setBusy(busy: Boolean, downloading: Boolean = false) {
        videoBtn.isEnabled = !busy
        audioBtn.isEnabled = !busy
        updateBtn.isEnabled = !busy
        cancelBtn.visibility = if (downloading) View.VISIBLE else View.GONE
        progress.visibility = if (busy && downloading) View.VISIBLE else View.GONE
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
