package com.example.ytdl

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

/** يحمّل في الخلفية ويعرض التقدّم في الإشعارات، دون الحاجة لفتح التطبيق */
class DownloadService : Service() {

    companion object {
        private const val CHANNEL = "downloads"
        private const val EXTRA_URL = "url"
        private const val EXTRA_AUDIO = "audio"
        private const val EXTRA_HEIGHT = "height"
        private const val ACTION_CANCEL = "cancel"
        private const val EXTRA_JOB = "job"
        private val nextId = AtomicInteger(100)

        fun start(context: Context, url: String, audio: Boolean, height: Int) {
            val i = Intent(context, DownloadService::class.java)
                .putExtra(EXTRA_URL, url)
                .putExtra(EXTRA_AUDIO, audio)
                .putExtra(EXTRA_HEIGHT, height)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(i) else context.startService(i)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active = AtomicInteger(0)
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "التحميلات", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            YoutubeDL.getInstance().destroyProcessById("job-${intent.getIntExtra(EXTRA_JOB, 0)}")
            return START_NOT_STICKY
        }
        val url = intent?.getStringExtra(EXTRA_URL) ?: return START_NOT_STICKY
        val audio = intent.getBooleanExtra(EXTRA_AUDIO, false)
        val height = intent.getIntExtra(EXTRA_HEIGHT, 0)
        val id = nextId.incrementAndGet()

        val builder = baseNotification(id, if (audio) "تحميل صوت" else "تحميل فيديو")
            .setContentText("جاري التجهيز...")
            .setProgress(100, 0, true)
        ServiceCompat.startForeground(
            this, id, builder.build(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        active.incrementAndGet()
        scope.launch { runJob(id, url, audio, height, builder) }
        return START_NOT_STICKY
    }

    private fun runJob(
        id: Int, url: String, audio: Boolean, height: Int, b: NotificationCompat.Builder
    ) {
        val outDir = File(cacheDir, "job-$id").apply { deleteRecursively(); mkdirs() }
        var lastPct = -1
        try {
            Downloader.init(this)
            val req = Downloader.buildRequest(url, outDir, audio, height)
            YoutubeDL.getInstance().execute(req, "job-$id") { p, eta, _ ->
                val pct = p.toInt()
                if (pct >= 0 && pct != lastPct) {
                    lastPct = pct
                    nm.notify(id, b.setProgress(100, pct, false)
                        .setContentText("$pct%  —  متبقٍّ $eta ث").build())
                }
            }
            val file = outDir.listFiles()?.maxByOrNull { it.length() }
                ?: throw Exception("لم يتم العثور على الملف")
            nm.notify(id, b.setContentText("جاري الحفظ...").setProgress(100, 0, true).build())
            val (path, uri) = Downloader.saveToDownloads(this, file, audio)
            finish(id, "تم التحميل ✓", path, uri, if (audio) "audio/mpeg" else "video/mp4")
        } catch (e: YoutubeDL.CanceledException) {
            finish(id, "تم الإلغاء", null, null, null)
        } catch (e: Exception) {
            finish(id, "فشل التحميل",
                (e.message?.takeLast(200) ?: "") + " — جرّب تحديث المحرّك من التطبيق", null, null)
        } finally {
            outDir.deleteRecursively()
        }
    }

    private fun finish(id: Int, title: String, text: String?, uri: android.net.Uri?, mime: String?) {
        // إشعار نهائي منفصل (معرّف مختلف) حتى لا يُحذف مع إيقاف الخدمة
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
        if (uri != null) {
            val open = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            n.setContentIntent(PendingIntent.getActivity(
                this, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        nm.cancel(id)
        nm.notify(id + 100000, n.build())
        if (active.decrementAndGet() <= 0) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun baseNotification(id: Int, title: String): NotificationCompat.Builder {
        val cancel = PendingIntent.getService(
            this, id,
            Intent(this, DownloadService::class.java)
                .setAction(ACTION_CANCEL).putExtra(EXTRA_JOB, id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "إلغاء", cancel)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
