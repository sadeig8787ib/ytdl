package com.example.ytdl

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import kotlin.math.abs

/**
 * خدمة تُظهر أيقونة تحميل صغيرة عائمة فقط عندما يكون يوتيوب في المقدمة.
 * تكتفي بمعرفة اسم التطبيق المفتوح ولا تقرأ محتوى الشاشة.
 * الضغط على الأيقونة يفتح قائمة الاختيار بالرابط المنسوخ. يمكن سحبها لتغيير مكانها.
 */
class BubbleService : AccessibilityService() {

    private val youtubeApps = setOf(
        "com.google.android.youtube",
        "com.google.android.apps.youtube.music",
        "app.revanced.android.youtube",
    )
    private val ignored = mutableSetOf("com.android.systemui")

    private var bubble: View? = null
    private lateinit var wm: WindowManager
    private val params by lazy {
        val size = (56 * resources.displayMetrics.density).toInt()
        WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - 16
            y = resources.displayMetrics.heightPixels / 3
        }
    }

    override fun onServiceConnected() {
        wm = getSystemService(WindowManager::class.java)
        ignored += packageName
        getSystemService(InputMethodManager::class.java)
            ?.enabledInputMethodList?.forEach { ignored += it.packageName }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        when {
            pkg in youtubeApps -> show()
            pkg in ignored -> Unit          // لوحة المفاتيح/شريط الإشعارات/تطبيقنا
            else -> hide()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun show() {
        if (bubble != null) return
        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_bubble)
            elevation = 8f
            contentDescription = "تحميل"
        }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(v, params)
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.rawX - touchX) < 15 && abs(e.rawY - touchY) < 15) openSheet()
                }
            }
            true
        }
        wm.addView(v, params)
        bubble = v
    }

    private fun hide() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
    }

    private fun openSheet() {
        startActivity(Intent(this, ShareActivity::class.java)
            .putExtra(ShareActivity.EXTRA_FROM_BUBBLE, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    override fun onInterrupt() = hide()
    override fun onDestroy() { hide(); super.onDestroy() }
}
